import { defineConfig } from '@playwright/test';

export default defineConfig({
  testDir: './tests', // test dosyalarının bulunduğu klasör
  timeout: 60 * 1000, // her test için maksimum süre
  expect: {
    timeout: 5000 // bekleme işlemleri için timeout
  },
  fullyParallel: true, // testleri paralel çalıştır
  retries: 1, // başarısız olan testleri 1 kez daha dene
  reporter: [['list'], ['html', { outputFolder: 'playwright-report', open: 'never' }]],
  use: {
    headless: true, // testler arka planda çalışsın
    viewport: { width: 1280, height: 720 },
    ignoreHTTPSErrors: true,
    video: 'retain-on-failure',
    screenshot: 'only-on-failure',
    baseURL: 'https://s4e.io/free-security-tools'
  },
});
