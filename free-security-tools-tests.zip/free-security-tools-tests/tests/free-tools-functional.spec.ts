import { test, expect } from '@playwright/test';

const baseUrl = 'https://s4e.io/free-security-tools';

test.describe('Free Security Tools Sayfası Testleri', () => {

  test('TC01 - Sayfa Başarıyla Yükleniyor', async ({ page }) => {
    const response = await page.goto(baseUrl);
    expect(response?.status()).toBe(200);
    await expect(page.locator('h1')).toContainText('Free Security Tools');
  });

  test('TC02 - Sayfa Başlığı ve Açıklama Görünüyor', async ({ page }) => {
    await page.goto(baseUrl);
    await expect(page.locator('h1')).toContainText(/Free Security Tools/i);
    await expect(page.locator('body')).toContainText(/Scan your assets with/i);
  });

 test('TC03 - Araç Kartları Yükleniyor', async ({ page }) => {
    // Sayfayı aç
    await page.goto('https://s4e.io/free-security-tools');

    // Araç kartlarını temsil eden <a> öğelerini bul
    const cards = page.locator('a[href^="/tools/"]');

    // İlk kartın görünmesini bekle
    await cards.first().waitFor({ state: 'visible', timeout: 10000 });

    // Kart sayısını kontrol et
    const count = await cards.count();
    expect(count).toBeGreaterThan(0);
 });

  test('TC04 - Her Kartta İsim Görünüyor', async ({ page }) => {
    await page.goto(baseUrl);
    const titles = page.locator('.tool-card h2'); // Kartlardaki başlıkları kontrol et
    const count = await titles.count();
    for (let i = 0; i < count; i++) {
      const text = await titles.nth(i).textContent();
      expect(text?.trim().length).toBeGreaterThan(0);
    }
  });

  test('TC05 - Her Kartta Açıklama Mevcut', async ({ page }) => {
    await page.goto(baseUrl);
    const descriptions = page.locator('.tool-card p'); // Kartlardaki açıklama
    const count = await descriptions.count();
    for (let i = 0; i < count; i++) {
      const text = await descriptions.nth(i).textContent();
      expect(text?.trim().length).toBeGreaterThan(0);
    }
  });

  test('TC06 - Her Kartta Ziyaret Linki Var', async ({ page }) => {
    // Sayfayı aç
    await page.goto('https://s4e.io/free-security-tools');

    // Kart linklerini seç (her biri bir araç)
    const links = page.locator('a[href^="/tools/"]');

    // Linklerin yüklenmesini bekle
    await links.first().waitFor({ state: 'visible', timeout: 10000 });

    // Linklerin sayısının 0'dan büyük olduğunu kontrol et
    const count = await links.count();
    expect(count).toBeGreaterThan(0);
 });

  test('TC07 - Arama Kutusu Görünüyor ve Kullanılabilir', async ({ page }) => {
    await page.goto(baseUrl);
    const input = page.locator('input[placeholder="Search tools name"]');
    await expect(input).toBeVisible();
    await input.fill('example');
    await expect(input).toHaveValue('example');
  });

 test('TC08 - Geçerli Arama Sonucu Döndürüyor', async ({ page }) => {
    // Sayfayı aç
    await page.goto('https://s4e.io/free-security-tools');

   // Arama kutusunu bul ve görünür hale gelmesini bekle
    const input = page.locator('input[placeholder="Search tool name"]');
    await input.waitFor({ state: 'visible', timeout: 10000 });  // 10 saniye bekle

   // Geçerli bir sorgu girin (örneğin “Wappalyzer” gibi mevcut bir araç adı)
    await input.fill('Wappalyzer');  // Burada "Wappalyzer" geçerli bir arama terimi olarak giriliyor

   // Arama sonucu kartını kontrol et
    const result = page.locator('a[href^="/tools/"]:has-text("Wappalyzer")');
    await expect(result).toBeVisible();  // Sonuç görünürse testi başarılı kabul et
 });
 
  test('TC09 - Geçersiz Arama Sonucu Mesajı', async ({ page }) => {
    // Sayfayı aç
    await page.goto('https://s4e.io/free-security-tools');

    // Arama kutusunu bul ve görünür hale gelmesini bekle
    const input = page.locator('input[placeholder="Search tool name"]');
    await input.waitFor({ state: 'visible', timeout: 10000 });  // 10 saniye bekle

    // Geçersiz bir arama değeri girin
    await input.fill('!@#$%^&*()');

    // Beklenen mesajın görünüp görünmediğini kontrol et
    const noResultsText = page.locator('text=No tools found');
    await expect(noResultsText).toBeVisible();  // "No tools found" mesajının görünür olmasını kontrol et
 });

  test('TC10 - Boş Arama Durumunda Tüm Kartlar Görünür', async ({ page }) => {
    // Sayfayı aç
    await page.goto('https://s4e.io/free-security-tools');

    // Arama kutusunun görünür olmasını bekle
    const input = page.locator('input[placeholder="Search tool name"]');
    await input.waitFor({ state: 'visible', timeout: 10000 });  // 10 saniye bekle

    // Arama kutusuna boş değer gir
    await input.fill('');

    // Kartların görünmesini bekle
    await page.waitForSelector('a[href^="/tools/"]', { timeout: 10000 });  // 10 saniye bekle

    // Kartların sayısını kontrol et
    const cards = await page.locator('a[href^="/tools/"]').count();
    expect(cards).toBeGreaterThan(0);  // Kart sayısının 0'dan büyük olmasını kontrol et
 });
 
 test('TC11 - Karttaki Link Tıklanabilir', async ({ page }) => {
    await page.goto(baseUrl);

  // Sayfanın yüklenmesi için bekle
    await page.waitForLoadState('domcontentloaded'); // DOM'un tamamen yüklenmesini bekleyin

  // Araç linklerinin görünmesini bekle
    await page.waitForSelector('a[href^="/tools/"]', { timeout: 10000 });

  // İlk aracı bul ve tıklanabilirliğini test et
    const firstLink = page.locator('a[href^="/tools/"]').first();
    await expect(firstLink).toBeVisible();
    await expect(firstLink).toHaveAttribute('href', /\/tools\//);
 });

  test('TC12 - Sayfa Responsive (Mobil/Dar Ekran)', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 }); // iPhone X boyutu
    await page.goto(baseUrl);
    await expect(page.locator('h1')).toBeVisible();
 });

 test('TC13 - Kartlarda Kategori/Etiket Görünüyor', async ({ page }) => {
    await page.goto('https://s4e.io/free-security-tools', { waitUntil: 'domcontentloaded' });

    await page.waitForSelector('a[href^="/tools/"] span', { timeout: 10000 });

    const tags = await page.locator('a[href^="/tools/"] span');
     expect(await tags.count()).toBeGreaterThan(0); // Etiketlerin görünürlüğünü test et
 });;

  test('TC14 - Araç Sayısı Beklenen Aralıkta', async ({ page }) => {
    await page.goto(baseUrl);
  
  // Sayfanın DOM'unun yüklenmesini bekle
    await page.waitForLoadState('domcontentloaded');
   
  // Alternatif doğru selector: tüm araç linklerini temsil eden bağlantılar
    await page.waitForSelector('a[href^="/tools/"]', { timeout: 10000 });

    const cards = await page.locator('a[href^="/tools/"]').count();
    expect(cards).toBeGreaterThan(0); // örnek kontrol

 });

  test('TC15 - Linkler Doğru Hedefe Yönlendiriyor', async ({ page }) => {
    await page.goto(baseUrl);
    const links = await page.locator('.tool-card a[href]').evaluateAll((as) =>
      as.map((a) => a.href)
    );
    for (const href of links) {
      expect(href.startsWith('http')).toBeTruthy(); // Bağlantıların http ile başlaması bekleniyor
    }
  });

});
