import { test, expect } from '@playwright/test';

const baseUrl = 'https://s4e.io/free-security-tools';

test.describe('Free Security Tools - Edge Case Testleri', () => {

 test('EC01 - Arama kutusuna çok uzun metin girilmesi', async ({ page }) => {
    // Sayfayı aç
    await page.goto('https://s4e.io/free-security-tools');

    // Arama kutusuna çok uzun metin gir
    const longText = 'a'.repeat(10000); // Çok uzun metin
    const input = page.locator('input[placeholder="Search tool name"]');
    await input.fill(longText);

    // Sayfa bozulmadı mı?
    const toolCards = page.locator('table tbody tr');
    await expect(toolCards).toHaveCount(0);  // Kart sayısının sıfır olmasını bekliyoruz çünkü çok uzun metin arama sonuçlarını getirmemeli
 });

  test('EC02 - Arama kutusuna sadece boşluk girilmesi', async ({ page }) => {
    await page.goto(baseUrl);
    const input = page.locator('input[placeholder="Search tools name"]');
    await input.fill('     ');
    await page.waitForTimeout(300);
    const tools = page.locator('table tbody tr');
    const noResult = page.locator('text=No tools found');
    expect(await tools.count() > 0 || await noResult.isVisible()).toBeTruthy();
  });

 test('EC03 - Arama kutusuna özel karakter girilmesi', async ({ page }) => {
    // Sayfayı aç
    await page.goto('https://s4e.io/free-security-tools');

    // Arama kutusuna özel karakterler gir
    const input = page.locator('input[placeholder="Search tool name"]');
    await input.fill('!@#$%^&*()');

    // Sayfa düzgün çalışıyor mu?
    const toolCards = page.locator('div[class^="tool"]');
    await expect(toolCards).toHaveCount(0);  // Arama sonucunda kart sayısının 0 olmasını bekliyoruz
});

 test('EC04 - SQL injection denemesi', async ({ page }) => {
    // Sayfayı aç
    await page.goto('https://s4e.io/free-security-tools');

    // Arama kutusuna SQL injection girişi yap
    const input = page.locator('input[placeholder="Search tool name"]');
    await input.fill(`' OR '1'='1`);

    // Sayfa düzgün çalışıyor mu?
    const toolCards = page.locator('div[class^="tool"]');
    await expect(toolCards).toHaveCount(0);  // Arama sonucunda kart sayısının 0 olmasını bekliyoruz
});

 test('EC05 - JavaScript injection denemesi', async ({ page }) => {
    // Sayfayı aç
    await page.goto('https://s4e.io/free-security-tools');

    // Arama kutusunun yüklenmesini bekle
    const input = page.locator('input[type="search"]');
    await input.waitFor({ state: 'visible', timeout: 10000 });  // 10 saniye kadar bekle

    // JavaScript enjeksiyonunu yap
    await input.fill('<script>alert("xss")</script>');

    // Sayfanın yüklenmesini bekle
    await page.waitForLoadState('load');
});
 
 test('EC06 - Bozuk link tıklandığında ana sayfa etkilenmemeli', async ({ page }) => {
    await page.goto('https://s4e.io/free-security-tools', { waitUntil: 'networkidle' });

  // Bozuk linki seç
    const brokenLink = page.locator('a[href="/non-existent-page"]');

  // Linkin varlığını kontrol et
    if (await brokenLink.count() > 0) {
      await brokenLink.click();
    // Ana sayfa öğesinin hala mevcut olduğunu doğrula
      const mainContent = page.locator('.main-content');
      await expect(mainContent).toBeVisible();
   } else {
      test.skip('Bozuk link bulunamadı.');
   }
 });

  test('EC07 - Bağlantı kopukluğunda davranış (Yorumlandı)', async ({ page }) => {
    // Not: Playwright ortamında fiziksel bağlantı kopması simüle edilemez.
    // Alternatif olarak boş sayfa kontrolü yapılabilir.
    await page.goto('about:blank');
    await expect(page.locator('body')).toBeVisible();
  });

  test('EC08 - Çok küçük mobil ekranlarda görünüm bozulmamalı', async ({ page }) => {
    await page.setViewportSize({ width: 320, height: 600 });
    await page.goto(baseUrl);
    await expect(page.locator('h1')).toBeVisible();
  });

 test('EC09 - Çok hızlı arka arkaya arama yapılması', async ({ page }) => {
   await page.goto(baseUrl);
  
   const input = page.locator('input[placeholder="Search tools name"]');
  
  // Hızlı bir şekilde farklı aramalar yapalım
   const searchTerms = ['scanner', 'test', 'vulnerability'];

   for (const term of searchTerms) {
     await input.fill(term);
     await page.waitForTimeout(300); // Her arama arasında kısa bir bekleme süresi

     const tools = page.locator('table tbody tr'); // Araçlar tablosundaki satırlar
     const count = await tools.count();
     expect(count).toBeGreaterThan(0); // En az bir araç olmalı
   }
 });

  test('EC10 - Klavye ile gezilebilirlik (erişilebilirlik)', async ({ page }) => {
    await page.goto(baseUrl);
    await page.keyboard.press('Tab');
    // Testin amacı hata oluşmaması, bu nedenle geçiş doğrulaması yapılmaz
    expect(true).toBeTruthy();
  });

});
