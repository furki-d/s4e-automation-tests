
# Edge Test Case Listesi – Free Security Tools Sayfası

Bu bölüm, https://s4e.io/free-security-tools sayfası için oluşturulmuş sınır (edge) durum test senaryolarını içerir.

---

### EC01 - Arama Kutusuna Çok Uzun Metin Girilmesi
**Açıklama:** Arama kutusuna çok uzun bir metin girilmesi durumunda sistemin davranışı test edilir
**Adımlar:**
  1. Arama kutusuna 1000 karakterden uzun rastgele bir metin gir
**Beklenen Sonuç:** Sayfa hata vermez, arama sonucu "bulunamadı" olarak gösterilir

---

### EC02 - Arama Kutusuna Sadece Boşluk Girilmesi
**Açıklama:** Arama kutusuna yalnızca boşluk girilirse sonuç davranışı test edilir
**Adımlar:**
  1. Arama kutusuna sadece boşluk yaz
**Beklenen Sonuç:** Ya tüm kartlar görünür ya da "bulunamadı" mesajı düzgün gösterilir

---

### EC03 - Arama Kutusuna Özel Karakter Girilmesi
**Açıklama:** Arama kutusuna @#$%^& gibi karakterler girildiğinde sistemin tepkisi
**Adımlar:**
  1. Arama kutusuna `!@#$%^&*()` yaz
**Beklenen Sonuç:** Sayfa hata vermez, geçersiz karakterlere göre mantıklı sonuç döner

---

### EC04 - Arama Kutusuna SQL Injection Denemesi
**Açıklama:** Güvenlik amacıyla SQL injection girişimi yapılır
**Adımlar:**
  1. Arama kutusuna `' OR '1'='1` gibi sorgu yaz
**Beklenen Sonuç:** Sayfa hiçbir özel tepki vermez, güvenli şekilde "bulunamadı" mesajı verir

---

### EC05 - JavaScript Enjeksiyonu Denemesi
**Açıklama:** XSS testi amaçlı input'a JavaScript kodu girilir
**Adımlar:**
  1. Arama kutusuna `<script>alert('xss')</script>` yaz
**Beklenen Sonuç:** Kod çalıştırılmaz, sayfa güvenli kalır

---

### EC06 - Bağlantılar Bozulduğunda (404)
**Açıklama:** Kart içindeki bağlantı 404 dönerse kullanıcıya uygun bilgi veriliyor mu?
**Adımlar:**
  1. Bozuk bir bağlantıya sahip kart simüle et (manuel olarak test edilir)
**Beklenen Sonuç:** Yeni sekme 404 açsa bile ana sayfa etkilenmez

---

### EC07 - İnternet Bağlantısı Kesildiğinde Sayfa Davranışı
**Açıklama:** Kullanıcı sayfayı kullanırken interneti kaybederse ne olur?
**Adımlar:**
  1. Sayfa yüklenirken interneti kapat
**Beklenen Sonuç:** Boş sayfa veya hata mesajı düzgün biçimde gösterilir

---

### EC08 - Mobilde Aşırı Küçük Ekran
**Açıklama:** 320px gibi çok dar ekranlarda görünüm bozuluyor mu?
**Adımlar:**
  1. Geliştirici modunda ekran genişliğini düşür
**Beklenen Sonuç:** Scroll dışında bozulma olmamalı, tüm içerikler erişilebilir olmalı

---

### EC09 - Çok Hızlı Arka Arkaya Arama Yapmak
**Açıklama:** Kullanıcı arama kutusuna hızlıca farklı şeyler yazdığında sayfa davranışı
**Adımlar:**
  1. Farklı kelimeleri 1-2 saniye aralıklarla yaz
**Beklenen Sonuç:** Sayfa donmaz ve son girilen metne göre sonuç döner

---

### EC10 - Klavyesiz Kullanım (Erişilebilirlik)
**Açıklama:** Sadece klavye kullanarak sayfa işlevselliği test edilir
**Adımlar:**
  1. Tab tuşu ile gez, Enter ile bağlantılara tıkla
**Beklenen Sonuç:** Her öğeye erişilebilir ve işlevsel olmalı

---
