
# S4E Free Security Tools Otomasyon Test Projesi

Bu proje, S4E.io **Test Engineer** pozisyonu için hazırlanmış teknik bir değerlendirme ödevidir. Projenin amacı, S4E’in *Free Security Tools* sayfası için Playwright ile otomasyon test senaryoları yazmaktır. Sunulan testler, sayfanın temel işlevlerini doğrulamak için tekil veya toplu şekilde çalıştırılabilir. Bu proje, test mühendisinin web otomasyon yetkinliğini göstermek üzere tasarlanmıştır.

## Kullanılan Araçlar ve Teknolojiler

- **Node.js & npm**: Proje çalıştırma ve bağımlılık yönetimi için.  
- **TypeScript**: Test kodlarının yazımı için güçlü tip desteği.  
- **Playwright Test**: Web tarayıcı otomasyonu için ana test kütüphanesi (Chromium/Firefox/WebKit).  
- **Jest (opsiyonel)**: İlaveten birim test veya ek doğrulamalar için kullanılabilir.  
- **npm komutları**: Proje kurulumu ve test çalıştırmaları için standart script’ler.  

## Kurulum

1. Bilgisayarınızda **Node.js** (14+ sürümü) kurulu olmalıdır.  
2. Proje dizininde terminal açın ve bağımlılıkları yükleyin:  
   ```bash
   npm install
   ```  
3. Playwright’in tarayıcı ikililerini yükleyin:  
   ```bash
   npx playwright install
   ```  
4. (İsteğe bağlı) Playwright’in ek bağımlılıklarını yükleyin (Linux ortamları için):  
   ```bash
   npx playwright install-deps
   ```  

## Testleri Çalıştırma

- **Tüm testleri çalıştırmak** için aşağıdaki komutu kullanın:  
  ```bash
  npx playwright test
  ```  
- **Tek bir testi çalıştırmak** için test dosyasını veya test adını belirtebilirsiniz:  
  ```bash
  npx playwright test tests/freeSecurityTools.spec.ts
  ```  
  veya belirli bir test açıklamasıyla:  
  ```bash
  npx playwright test --grep "TC01"
  ```  
- `package.json` içinde `"test"` script’i tanımlanmışsa `npm test` komutu da kullanılabilir.  

## Dosya Yapısı

- **tests/**: Playwright ile yazılmış test senaryosu dosyaları (`.spec.ts`).  
- **playwright.config.ts**: Test yapılandırma ayarlarını içeren dosya (tarayıcı ayarları, timeout, reporter vb.).  
- **package.json**: Projenin bağımlılıkları ve npm script’leri.  
- **tsconfig.json**: TypeScript derleyici ayarları.  
- **node_modules/**: npm ile yüklenen paketler (git'te saklanmaz).  

## Test Senaryoları

- **TC01**: Sayfa düzgün şekilde yükleniyor mu kontrol edilir.  
- **TC02**: Sayfa üzerindeki başlık ve açıklama metinleri görünür olmalı.
- **TC03**: Sayfadaki araç kartları düzgün şekilde listeleniyor mu?  
- **TC04**: Her kartta araç ismi yazmalı.  
- **TC05**: Kartların açıklama içerdiği kontrol edilir.  
- **TC06**: Karttaki bağlantı linkleri mevcut mu?  
- **TC07**: Sayfada arama kutusu olup olmadığı ve çalışıp çalışmadığı kontrol edilir.  
- **TC08**: Geçerli bir arama sonucu uygun araçları getiriyor mu?  
- **TC09**: Hiçbir eşleşme olmadığında kullanıcı bilgilendiriliyor mu?  
- **TC10**: Arama kutusu boşken varsayılan tüm araçlar görünür mü? 
- **TC11**: Karttaki Link Tıklanabilir mi?
- **TC12**: Sayfa mobil cihazlarda bozulmadan görüntüleniyor mu?
- **TC13**: Her araç uygun kategori ya da etiketle etiketlenmiş mi?
- **TC14**: Gösterilen araç sayısı sistemde tanımlı sınırlar içinde mi?
- **TC15**: Karttaki linkler doğru hedefe yönlendiriyor mu?
- **EC01**: Arama kutusuna çok uzun bir metin girilmesi durumunda sistemin davranışı test edilir.  
- **EC02**: Arama kutusuna yalnızca boşluk girilirse sonuç davranışı test edilir.  
- **EC03**: Arama kutusuna @#$%^& gibi karakterler girildiğinde sistemin tepkisi.  
- **EC04**: Güvenlik amacıyla SQL injection girişimi yapılır.  
- **EC05**: XSS testi amaçlı input'a JavaScript kodu girilir.  
- **EC06**: Kart içindeki bağlantı 404 dönerse kullanıcıya uygun bilgi veriliyor mu? 
- **EC07**: Kullanıcı sayfayı kullanırken interneti kaybederse ne olur?
- **EC08**: 320px gibi çok dar ekranlarda görünüm bozuluyor mu? 
- **EC09**: Kullanıcı arama kutusuna hızlıca farklı şeyler yazdığında sayfa davranışı 
- **EC10**: Sadece klavye kullanarak sayfa işlevselliği test edilir 

## Yapılandırma Özeti (playwright.config.ts)

Test konfigürasyonu `playwright.config.ts` dosyasında tanımlanmıştır. Önemli ayarlar:

- **testDir**: Test dosyalarının konumunu gösterir (ör. `./tests`).  
- **timeout**: Her bir test için maksimum süre (örn. 30000ms).  
- **retries**: Başarısız testlerin tekrar deneme sayısı (örn. 0 veya 1).  
- **use**: Genel kullanım ayarları:
  - `baseURL`: Temel test URL'si (`https://s4e.io/free-security-tools`).  
  - `headless`: Tarayıcının headless modda çalışıp çalışmayacağı (örn. `true`).  
  - `viewport`: Tarayıcı görünüm boyutu (örn. genişlik/yükseklik).  
- **reporter**: Test sonuç raporlayıcıları. Örneğin konsolda `list` veya detaylı HTML rapor (`html`) kullanılabilir. Aşağıda örnek bir yapılandırma snippet’i gösterilmiştir:

```ts
// playwright.config.ts (örnek)
export default {
  testDir: './tests',
  timeout: 30000,
  retries: 0,
  use: {
    baseURL: 'https://s4e.io/free-security-tools',
    headless: true,
    viewport: { width: 1280, height: 720 }
  },
  reporter: [['list'], ['html', { outputFolder: 'playwright-report', open: 'never' }]]
};
```

## Test Sonuçlarının Görüntülenmesi

Playwright testleri çalıştırıldığında sonuçlar konsolda özetlenir. Ayrıca **HTML rapor** özelliği ile görsel raporlar oluşturulabilir:

- HTML rapor oluşturmak için `playwright.config.ts` içinde `reporter: [['html']]` şeklinde ayar yapılmıştır.  
- Testler tamamlandıktan sonra raporu görüntülemek için terminalde aşağıdaki komutu kullanın:  
  ```bash
  npx playwright show-report
  ```  
- Açılan HTML rapor penceresinde testlerin geçme/kalma durumu, hata detayları ve isteğe bağlı ekran görüntüleri görülebilir.

## Otomatik Rapor Açma Özelliği

Konfigürasyonda, HTML raporun otomatik açılması için `open` seçeneği kullanılabilir. Örneğin:  
```ts
reporter: [['html', { open: 'on-failure' }]]
```  
şeklinde ayarlandığında, testler başarısız olduğunda HTML rapor otomatik olarak tarayıcıda açılacaktır. Bunun yanı sıra, her test çalıştırıldıktan sonra raporu otomatik açmak için `open: 'always'` veya CLI argümanı `--reporter=html` seçenekleri de tercih edilebilir. Bu sayede test sonrası rapora kolay erişim sağlanır.

## Teslimat ve İletişim

- Projenin kaynak kodu bir **GitHub deposu**nda sunulmuştur. (Örnek: `https://github.com/kullanici/s4e-playwright-tests`)  
- Projeyi incelemek için ilgili repo klonlanabilir:  
 
- Projeyle ilgili soru veya geri bildirimleriniz için iletişime geçebilirsiniz:  
  - **Furkan DİLEK**,
  - **LinkedIn** : https://www.linkedin.com/in/furkan-dilek-b283a3226/
