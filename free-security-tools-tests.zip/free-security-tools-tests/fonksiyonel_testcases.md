
# Test Case Listesi – Free Security Tools Sayfası

Bu doküman, https://s4e.io/free-security-tools sayfası için oluşturulmuş fonksiyonel test senaryolarını içermektedir.

---

### TC01 - Sayfa Başarıyla Yükleniyor
**Açıklama:** Sayfa düzgün şekilde yükleniyor mu kontrol edilir.
**Adımlar:**
  1. https://s4e.io/free-security-tools sayfasına git
  2. Sayfa başlığını ve HTTP yanıtını kontrol et
**Beklenen Sonuç:** Sayfa HTTP 200 ile döner ve başlık görünür

---

### TC02 - Sayfa Başlığı ve Açıklama Görünüyor
**Açıklama:** Sayfa üzerindeki başlık ve açıklama metinleri görünür olmalı
**Adımlar:**
  1. Sayfayı aç
  2. Başlık ve açıklama metninin varlığını kontrol et
**Beklenen Sonuç:** "Free Security Tools" başlığı ve açıklama görünür

---

### TC03 - Araç Kartları Yükleniyor
**Açıklama:** Sayfadaki araç kartları düzgün şekilde listeleniyor mu?
**Adımlar:**
  1. Sayfayı aç
  2. Kart elemanlarını say
**Beklenen Sonuç:** En az 1 kart görünür

---

### TC04 - Her Kartta İsim Görünüyor
**Açıklama:** Her kartta araç ismi yazmalı
**Adımlar:**
  1. Tüm kartları tara
  2. Her kartta başlık (isim) olup olmadığını kontrol et
**Beklenen Sonuç:** Tüm kartlarda araç ismi yer alır

---

### TC05 - Her Kartta Açıklama Mevcut
**Açıklama:** Kartların açıklama içerdiği kontrol edilir
**Adımlar:**
  1. Her kartı kontrol et
  2. Açıklama metni içeriyor mu bak
**Beklenen Sonuç:** Her kart açıklama içerir

---

### TC06 - Her Kartta Ziyaret Linki Var
**Açıklama:** Karttaki bağlantı linkleri mevcut mu?
**Adımlar:**
  1. Her kartta "Visit" butonu veya bağlantı var mı kontrol et
**Beklenen Sonuç:** Tüm kartlarda link bulunmalı

---

### TC07 - Arama Kutusu Görünüyor ve Kullanılabilir
**Açıklama:** Sayfada arama kutusu olup olmadığı ve çalışıp çalışmadığı kontrol edilir
**Adımlar:**
  1. Arama kutusunu bul
  2. Kullanıcı girişi yapılabilir mi test et
**Beklenen Sonuç:** Arama kutusu görünür ve veri girilebilir

---

### TC08 - Geçerli Arama Sonucu Döndürüyor
**Açıklama:** Geçerli bir arama sonucu uygun araçları getiriyor mu?
**Adımlar:**
  1. Arama kutusuna "scanner" yaz
  2. Sonuçları kontrol et
**Beklenen Sonuç:** En az bir araç listelenmeli

---

### TC09 - Geçersiz Arama Sonucu Mesajı
**Açıklama:** Hiçbir eşleşme olmadığında kullanıcı bilgilendiriliyor mu?
**Adımlar:**
  1. Arama kutusuna "asdfzxcv" yaz
**Beklenen Sonuç:** "Sonuç bulunamadı" veya benzeri mesaj gösterilmeli

---

### TC10 - Boş Arama Durumunda Tüm Kartlar Görünür
**Açıklama:** Arama kutusu boşken varsayılan tüm araçlar görünür mü?
**Adımlar:**
  1. Arama kutusunu temizle
**Beklenen Sonuç:** Tüm araç kartları tekrar görünür

---

### TC11 - Karttaki Link Tıklanabilir
**Açıklama:** Kart içindeki link çalışıyor mu?
**Adımlar:**
  1. Bir kartın "Visit" bağlantısına tıkla
**Beklenen Sonuç:** Yeni sekmede dış bağlantı açılır

---

### TC12 - Sayfa Responsive (Mobil/Dar Ekran)
**Açıklama:** Sayfa mobil cihazlarda bozulmadan görüntüleniyor mu?
**Adımlar:**
  1. Tarayıcıyı mobil görünüm moduna al (örnek: iPhone X)
**Beklenen Sonuç:** Sayfa düzgün görüntülenir, içerik taşmaz

---

### TC13 - Kartlarda Kategori/Etiket Görünüyor
**Açıklama:** Her araç uygun kategori ya da etiketle etiketlenmiş mi?
**Adımlar:**
  1. Kartlardaki tag'leri kontrol et
**Beklenen Sonuç:** Etiketler görünür olmalı (örneğin: "Web", "Scanner", vb.)

---

### TC14 - Araç Sayısı Beklenen Aralıkta
**Açıklama:** Gösterilen araç sayısı sistemde tanımlı sınırlar içinde mi?
**Adımlar:**
  1. Kart sayısını say
**Beklenen Sonuç:** Belirli bir minimum araç sayısı (örneğin 10+) görüntülenmeli

---

### TC15 - Linkler Doğru Hedefe Yönlendiriyor
**Açıklama:** Karttaki linkler doğru hedefe yönlendiriyor mu?
**Adımlar:**
  1. Tüm bağlantıların href değerlerini kontrol et
**Beklenen Sonuç:** URL’ler beklenen güvenlik araç sitelerine yönlendirir

---
